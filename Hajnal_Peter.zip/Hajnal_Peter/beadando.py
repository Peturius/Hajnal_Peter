import PIL
from PIL import Image
from enum import Enum
import tkinter as tk
import math
from datetime import datetime


matrix = []
kimenet = []

an_image = PIL.Image.open("perlin.png")
log_txt = open("log.txt", "a+", encoding = "UTF-8")

def feltoltes():
    adatokk = []

    log_is = 0

    for i in range(512):
        kislista = []
        for j in range(512):
            coord = i, j
            kislista.append(coord)
        adatokk.append(kislista)

    max = 0
    for sor in adatokk:
        kislista = []
        for elem in sor:
            ellem = an_image.getpixel(elem)

            if ellem[0] > max:
                max = ellem[0]

    for sor in adatokk:
        kislista = []
        for elem in sor:
            ellem = an_image.getpixel(elem)
            kislista.append(round(ellem[0] / max,2))
        matrix.append(kislista)

class szinek(Enum):
    Nagyonbarna = (51, 25, 0)
    Sotetbarna = (102, 51, 0)
    Vilagosbarna = (204, 102, 0)
    Vilagoszold = (0, 204, 0)
    Vilagoskek = (0, 0, 204)
    Sotetkek = (0, 0, 128)

class alap():
    """
    az alap nevű class felel a mátrix színkódolásáért

    konstruktor paramétere a mátrix és a tengerszint, ami az alap inicializáláskor a 0.5-öt vette fel
    ez alkotja meg a a színkódolást
    image_maker pedig ráteszi a a kimenet mátrixra és képet alkot
    """

    def __init__(self, matrix, vil_zold = 0.5):
        self.vil_zold = vil_zold
        self.matrix = matrix
        self.sot_barna = (vil_zold + 1) / 2
        self.vil_barna = (self.sot_barna + vil_zold) / 2
        self.vil_kek = (vil_zold - (vil_zold / 5))
        self.nagyon_barna = ((self.sot_barna + 1) / 2)
        self.nagyon_barna = (self.sot_barna + self.nagyon_barna) / 2

    def image_maker(self):
        for sor in self.matrix:
            for elem in sor:
                if elem >= (self.nagyon_barna):
                    kimenet.append(szinek.Nagyonbarna.value)
                elif elem >= (self.sot_barna):
                    kimenet.append(szinek.Sotetbarna.value)
                elif elem >= (self.vil_barna):
                    kimenet.append(szinek.Vilagosbarna.value)
                elif elem >= (self.vil_zold):
                    kimenet.append(szinek.Vilagoszold.value)
                elif elem >= (self.vil_kek):
                    kimenet.append(szinek.Vilagoskek.value)
                elif elem >= (0):
                    kimenet.append(szinek.Sotetkek.value)

        img = Image.new("RGB", (512, 512))
        newdata = kimenet
        img.putdata(newdata)
        img.save("kimenet.png")

class szintvalaszto(alap):
    """
    subclass, ami jogot ad arra, hogy állítható legyen a  tengerszint magassága
    """
    def __init__(self, matrix, vil_zold):
        self.vil_zold = vil_zold
        super().__init__(matrix, vil_zold)

class szint_log(alap):
    """
    a feladat pontatlansága miatt nem tudtam lehet-e a harmadik class egy sub-sub-class, ezért a szint_log is az alap leszármazottja
    log_is : készítsen-e logot Bool
    """
    def __init__(self, matrix, vil_zold):
        self.vil_zold = vil_zold
        super().__init__(matrix, vil_zold)
        global log_is
        log_is = 1

feltoltes()

root1 = tk.Tk()
root1.geometry("400x150")
root1.resizable(0, 0)
tk.Label(root1, text = "A térkép hány százalékát borítsa víz?\n(ajánlott: 35-80%)").pack()


def bevitel():
    szazalek = szint_txt.get(1.0, "end-1c")
    szintvalaszto(matrix, int(szazalek) / 100).image_maker()  # javasolt 35-80%
    root1.destroy()

def is_log():
    szazalek = szint_txt.get(1.0, "end-1c")
    szint_log(matrix, int(szazalek) / 100).image_maker()  # javasolt 35-80%
    root1.destroy()


szint_txt = tk.Text(root1, height = 1, width = 4)

szint_txt.pack()

button1 = tk.Button(root1, text = "Generálás!", command = bevitel)
button2 = tk.Button(root1, text = "Generálás log-gal!", command = is_log)

button1.pack()
button2.pack()
root1.mainloop()

#-----------------------------

root2 = tk.Tk()
root2.title("Mérd meg magad térkép!")

canvas = tk.Canvas(width = 512, height = 512, bg = 'black')
canvas.pack(expand = 'yes', fill = 'both')

kep = tk.PhotoImage(file = 'kimenet.png')
canvas.create_image(0, 0, image = kep, anchor = 'nw')

root2.resizable(0, 0)

katt = {"x1": None, "y1": None, "x2": None, "y2": None}

def vonal(event):
    if katt["x1"] == None:

        katt["x1"] = event.x
        katt["y1"] = event.y

        if log_is == 1:
            most = datetime.now()
            most_2 = most.strftime("%H:%M:%S")

            log_txt.write(f"Mérés időpontja: {most_2}\n")
            log_txt.write(f"Első pont: x= {event.x} y= {event.y}\n")

    else:
        katt["x2"] = event.x
        katt["y2"] = event.y

        if log_is == 1:
            log_txt.write(f"Második pont: x= {event.x} y= {event.y}\n")

        canvas.create_line(katt["x1"], katt["y1"], katt["x2"], katt["y2"], fill="red", width=3)
        d = math.sqrt((katt["x2"] - katt["x1"]) ** 2 + (katt["y2"] - katt["y1"]) ** 2)

        if log_is == 1:
            log_txt.write(f"Távolságuk: {round(d,2)} km\n\n")

        katt.clear()
        katt.setdefault("x1", None)


canvas.bind('<Button-1>', vonal)

def exterminate():
    root2.destroy()

button3 = tk.Button(root2, text = "EXIT", bg = "pink", command = exterminate)
button3.pack()
root2.mainloop()
log_txt.close()


